const express = require('express');
const mongoose = require('mongoose');
const ejs = require('ejs');
const axios = require('axios');
const bodyParser = require('body-parser');
const pdf = require('pdfkit');
const fs = require('fs');
const multer = require('multer');
const path = require('path');

const app = express();
const router = express.Router();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb://0.0.0.0:27017/Bookify');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
});

const User = mongoose.model('User', userSchema);

const adminSchema = new mongoose.Schema({
  username: String,
  password: String,
});

const Admin = mongoose.model('Admin', adminSchema);

const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  category: String,
  price: Number,
  discountPrice: Number,
  image: String,
});

const Book = mongoose.model('Book', bookSchema);

const transactionSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  address: String,
  city: String,
  state: String,
  zipCode: String,
  cardName: String,
  cardNumber: String,
  expMonth: String,
  expYear: String,
  cvv: String,
});

const Transaction = mongoose.model('Transaction', transactionSchema);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/'); // Specify the directory to store uploaded images
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname); // Generate a unique filename
  },
  limits: {
    fileSize: 1024 * 1024 * 5, // 5 MB limit
  },
});

// Initialize multer with the defined storage
const upload = multer({ storage: storage });

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/admin/updateBook/:id', upload.single('image'));

// User Authentication Routes
router.get('/signup', (req, res) => {
  res.render('signup');
});

router.get('/login', (req, res) => {
  res.render('login');
});

router.post('/signup', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if the username already exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).send('Username already exists');
    }

    // Create a new user in the database
    const newUser = new User({ username, password });
    await newUser.save();

    res.render('login');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if the user exists in the database
    const user = await User.findOne({ username, password });
    if (user) {
      const featuredBooks = await Book.find().limit(6);
      const newArrivals = await Book.find().skip(6).limit(6);
  
      res.render('index', { featuredBooks, newArrivals });
    } else {
      res.status(401).send('Invalid username or password');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Homepage Route
router.get('/', async (req, res) => {
  try {
    // Fetch featured and new arrival books
    const featuredBooks = await Book.find().limit(6);
    const newArrivals = await Book.find().skip(6).limit(6);

    res.render('index', { featuredBooks, newArrivals });
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Search Results Route
// Search Results Route
// Assuming you've already handled the API key and updated the API endpoint
router.post('/search', async (req, res) => {
  try {
    const searchTerm = req.body.searchTerm;
    const apiKey = 'AIzaSyCddjx3FH95ALyvuG-IFjonI-k0qLtDmcs'; // Replace with your actual API key
    
    const apiResponse = await axios.get(`https://www.googleapis.com/books/v1/volumes?q=${searchTerm}&key=${apiKey}`);
    const searchResults = apiResponse.data.items || [];

    res.render('searchResults', { searchResults });
  } catch (error) {
    console.error('Error fetching search results:', error.message);
    res.status(500).send('Internal Server Error');
  }
});



router.get('/payment',(req,res)=>{  
  res.render('payment');
})
// Payment Routes
router.post('/processPayment', async (req, res) => {
  try {
    // Save transaction data to MongoDB
    const newTransaction = new Transaction(req.body);
    await newTransaction.save();

    // Generate PDF
    const pdfDoc = new pdf();
    pdfDoc.text('Transaction Receipt\n\n');
    pdfDoc.text(`Full Name: ${req.body.fullName}\n`);
    // Add other details as needed
    pdfDoc.end();

    // Set the response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=transaction_receipt.pdf');

    // Pipe the PDF content to the response
    pdfDoc.pipe(res);

    // Send success response to the client
    res.json({ success: true, message: 'Payment successful' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Add a route for downloading the receipt
router.get('/downloadReceipt', (req, res) => {
  const filePath = path.join(__dirname, 'transaction_receipt.pdf');

  // Send the file as a response
  res.download(filePath, 'transaction_receipt.pdf', (err) => {
    if (err) {
      console.error(err);
      res.status(500).json({ success: false, message: 'Error downloading receipt' });
    } else {
      // Optionally, you can delete the file after it's downloaded
      fs.unlink(filePath, (unlinkErr) => {
        if (unlinkErr) {
          console.error(unlinkErr);
        }
      });
    }
  });
});


// Admin Routes

router.get('/admin/login',(req,res)=>{
  res.render('adminLogin');
})

router.post('/admin/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if the user exists in the database
    const admin = await Admin.findOne({ username, password });
    if (admin) {
      res.render('adminPanel')
    } else {
      res.status(401).send('Invalid admin credentials');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});


router.get('/admin/addBook', (req, res) => {
  res.render('addBook'); // Create an addBook.ejs template for rendering the form
});

// Route to handle the form submission and add a new book to the database
router.post('/admin/addBook', upload.single('image'), async (req, res) => {
  const { title, author, category, price, discountPrice } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : '/default-image.jpg';

  try {
    // Create a new book instance
    const newBook = new Book({
      title,
      author,
      category,
      price,
      discountPrice,
      image,
    });

    // Save the new book to the database
    await newBook.save();

    res.redirect('/admin/manageBooks'); // Redirect to manageBooks page after adding the book
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.get('/admin/manageBooks', async (req, res) => {
  try {
    // Fetch all books for managing inventory
    const books = await Book.find();
    res.render('manageBooks', { books });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

router.get('/admin/updateBook/:id', async (req, res) => {
  const bookId = req.params.id;

  try {
    // Fetch book details by ID
    const book = await Book.findById(bookId);
    if (book) {
      res.render('updateBook', { book }); // Render the update form with book details
    } else {
      res.status(404).send('Book not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.post('/admin/updateBook/:id', upload.single('image'), async (req, res) => {
  console.log(req.body);
  console.log(req.file); // Log the uploaded file details
  console.log(req.body);
  const bookId = req.params.id;
  const { title, author, category, price, discountPrice, image } = req.body;

  // Check if bookId is a valid ObjectId
  if (!mongoose.isValidObjectId(bookId)) {
    return res.status(400).send('Invalid bookId');
  }

  try {
    // Update book logic
    const updatedBook = await Book.findByIdAndUpdate(
      bookId,
      { title, author, category, price, discountPrice, image },
      { new: true }
    );

    if (updatedBook) {
      res.redirect('/admin/manageBooks');
    } else {
      res.status(404).send('Book not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.get('/admin/deleteBook/:id', async (req, res) => {
  const bookId = req.params.id;

  try {
    // Delete book logic
    const deletedBook = await Book.findByIdAndDelete(bookId);

    if (deletedBook) {
      res.redirect('/admin/manageBooks'); // Redirect to manageBooks page after deleting
    } else {
      res.status(404).send('Book not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.get('/admin/manageOrders', async (req, res) => {
  try {
    // Fetch all transactions for managing orders
    const transactions = await Transaction.find();
    res.render('manageOrders', { transactions });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

router.get('/admin/viewOrder/:id', async (req, res) => {
  const orderId = req.params.id;

  try {
    // Fetch the specific order by ID
    const order = await Transaction.findById(orderId);
    if (order) {
      res.render('viewOrder', { order }); // Create a viewOrder.ejs template for displaying detailed order view
    } else {
      res.status(404).send('Order not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

// Example route handler for dynamic product pages
app.get('/product/:id', (req, res) => {
  const productId = req.params.id;
  // Fetch details for the specified product using productId
  // Render the product page with the fetched details
  res.render('product-Page', { productId });
});

app.use('/',router);
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});